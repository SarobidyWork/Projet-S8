 clear all
 close all
 
 Nx = 100;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Test 1 : on verifie que Lamdbda U = f 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% avec la methode de Vuong
 a = 0;
 b = 1 ;
 n = Nx + 1 ;
 dx = (b-a) /Nx ;
 dt = dx ; 
 T = 4
 m = ceil(T/dt)+1 ;
 mu = 1 ;
 
 bl = 0 ;
 br = 0;
 x = (dx : dx :b-dx) ;
 U0 = u0(x) 
 U0t = u0t(x) ; 
 Y = Lambda(U0,U0t,mu,bl,br,a,b,T,n,m);
 f0 = sin(pi*x)' ; f1 = zeros(size(x));
 
 
 fmod0 = f0 ;
 c = ones(Nx-1,1);
 A = spdiags([-c 2*c -c],-1:1,Nx-1,Nx-1);
 A = 1/dx^2*A;
 fmod1 = -A\f1' ;
 

  figure(1) 
  plot(x,Y(Nx:(2*Nx-2)), 'r') 
  hold on
  plot(x, fmod0, 'k--', 'linewidth', 2) 
 
  legend('cible approche','cible exacte') 
  title('Test 1')
 
 
  Erreur = [ (Y(1:Nx-1)-fmod1 )  (Y(Nx:(2*Nx-2)) -fmod0)] 
  NormeErreur = NormeB(Erreur)
  
%  
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Test 2 : on test la methode du Gradient conjugue pour resoudre Lambda U =
% F 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 %%% Test 2  : on teste la methode du gradient conjugue
  
 
  e0 = zeros(size(x)) ;
  e1 = zeros(size(x)) ;
  U0 =   e0 ;
  U0t = e1 ;
  Y = Lambda(U0,U0t,mu,bl,br,a,b,T,n,m) ;
  y0 = Y(1:Nx-1);
  y1 = Y(Nx:(2*Nx-2));
  
 
  fmod0 = f0 ;
  c = ones(Nx-1,1);
  A = spdiags([-c 2*c -c],-1:1,Nx-1,Nx-1);
  A = 1/dx^2*A;
  fmod1 = -A\f1' ;
  
  
  %second membre
  R = [ fmod1- y0,fmod0 - y1];
  P = R;
  k = 1;
  tolerance = 0.0001 ;
  maxiter = 300;
  residu =(NormeB(R))
  LambdaP = zeros(Nx-1,2);
  while(k<maxiter && sqrt(NormeB(R))>tolerance)
    k
    U0 = P(1:Nx-1,1) ;
    U0t = P(1:Nx-1,2) ;
   
    Y = Lambda(U0,U0t,mu,bl,br,a,b,T,n,m) ;
    
    LambdaP(:, 1) = Y(1:Nx-1);
    LambdaP(:, 2) =  Y(Nx:2*Nx-2);
    
 

    
    prodscal = ProduitScalaireB(LambdaP,P);
    alpha = NormeB(R)/ProduitScalaireB(LambdaP,P);
    residu = (NormeB(R))
    %alpha = r'*r/((p'*A)*p);
  
   %e0(:,k+1) = e0(:,k) + alpha*P(:,1);
   %e1(:,k+1) = e1(:,k) + alpha*P(:,2);
    e0 = e0 + alpha*P(:,1);
    e1 = e1 + alpha*P(:,2);
  
    R1 = R - alpha*LambdaP;
    
    
    

    
    beta = NormeB(R1)/NormeB(R);
    
    %beta = r1'*r1/(r'*r);
    
    %r = r1;
    P = R1 + beta*P;
    %p = r + beta*p;
    R = R1;
    k=k+1;
  end
  e1_exact = -sin(pi*x)/(4 );
  figure(2) 
  plot(x,e1, 'r') 
  hold on
  plot(x, e1_exact, 'k--', 'linewidth', 2) 
  legend('e approche','e exacte') 
  title('Test du gradient conjugue')
    
% 


